# Movie-Recommendation-System
movie recommendation system using collaborative filtering and machine learning techniques in Python.
<img width="935" alt="Screenshot 2024-03-01 000101" src="https://github.com/ritika8803/Movie-Recommendation-System/assets/115074038/ddf48833-bb66-4554-ab88-42f651aa7f5b">
